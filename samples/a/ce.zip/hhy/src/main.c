#include <zephyr/kernel.h>
#include <zephyr/device.h>
#include <zephyr/drivers/can.h>
#include <zephyr/logging/log.h>
#include <stdint.h>
#include <string.h>
#include <sys/_intsup.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/drivers/sbus.h>
#include <zephyr/devicetree.h>
#include "zephyr/sys/time_units.h"
#include <zephyr/drivers/motor.h>
#include <zephyr/drivers/gpio.h>
#include <math.h>
#include "devices.h"

LOG_MODULE_REGISTER(lift_demo, LOG_LEVEL_INF);

#define SBUS_NODE DT_NODELABEL(sbus0)
const struct device *sbus = DEVICE_DT_GET(SBUS_NODE);

#define PI 3.1415926f
#define deg2high(deg)  ((deg) * PI * 45.0f / 360.0f)
#define high2deg(high) ((high) * 360.0f / (PI * 45.0f))
#define MIT_HOLD_RPM       0.0f


// ================= 全局变量 (保持原名) =================

// 目标角度（deg）
float action[4] = {0.0f, 0.0f, 0.0f, 0.0f};  // ⚠️ 不要全0，方便观察

int rank[4] = {-1, -1, 1, 1};
static const float motor_ff[4] = {0.5f, 1.8f, 0.5f, 1.8f};

// 电机设备指针数组（运行时初始化）
const struct device *dm_motor[4];


// ================= 电机位置控制 (保持原名) =================

void lifthigh(int id, float target_deg)
{
    float torque_ff = 0.0f;

    if (!device_is_ready(dm_motor[id])) {
        LOG_ERR("motor %d not ready!", id);
        return;
    }

    if (target_deg > 0.0f) {
        torque_ff = motor_ff[id];
    } else if (target_deg < 0.0f) {
        torque_ff = -motor_ff[id];
    }

    // MIT位置控制 + 重力补偿前馈力矩
    motor_set_mit(dm_motor[id],
                  MIT_HOLD_RPM,
                  target_deg,
                  torque_ff);
}

static void hold_current_target(void)
{
    for (int i = 0; i < 4; i++) {
        lifthigh(i, action[i]);
    }
}


// ================= 档位控制 =================

#define SBUS_DEADZONE      0.05f                // 死区阈值
#define SBUS_DIRECTION_CH  4
#define SBUS_TRIGGER_CH    7


static const float gear_angle_ac[] = {
    0.0f,
    360.0f,
    720.0f,
    1440.0f,
    2880.0f,
};

static const float gear_angle_bd[] = {
    50.0f,
    410.0f,
    770.0f,
    1490.0f,
    2930.0f,
};

#define MAX_GEAR ARRAY_SIZE(gear_angle_ac)      // 最大档位数

static int current_gear = 0;                    // 当前档位 (0-4)
static float last_trigger_sbus = 0.0f;          // 上一次触发通道的值
static int change_count = 0;                    // 触发通道变化计数器

// 检测触发通道是否有变化（超过死区）
static bool trigger_sbus_changed(float current, float last)
{
    float diff = current - last;
    if (diff < 0) diff = -diff;  // fabsf
    return diff > SBUS_DEADZONE;
}

// 档位控制逻辑
void gear_control_update(float direction_sbus, float trigger_sbus)
{
    // 检测触发通道是否变化
    bool changed = trigger_sbus_changed(trigger_sbus, last_trigger_sbus);
    last_trigger_sbus = trigger_sbus;

    if (!changed) {
        return;  // 触发通道没变化，不动作
    }

    change_count++;  // 变化次数+1
    LOG_INF("CH%d changed, count: %d/2", SBUS_TRIGGER_CH, change_count);

    if (change_count < 2) {
        return;
    }

    change_count = 0;

    if (direction_sbus > SBUS_DEADZONE) {
        // 上升一个档位
        if (current_gear < MAX_GEAR - 1) {
            current_gear++;
        }
        LOG_INF("Gear Up: %d/%d, Angle: %.1f deg",
                current_gear + 1, MAX_GEAR,
                (double)gear_angle_ac[current_gear]);
    } else if (direction_sbus < -SBUS_DEADZONE) {
        // 下降一个档位
        if (current_gear > 0) {
            current_gear--;
        }
        LOG_INF("Gear Down: %d/%d, Angle: %.1f deg",
                current_gear + 1, MAX_GEAR,
                (double)gear_angle_ac[current_gear]);
    } else {
        return;
    }

    {
        float target_angle_ac = gear_angle_ac[current_gear];
        float target_angle_bd = gear_angle_bd[current_gear];

        action[0] = target_angle_ac * rank[0];
        action[1] = target_angle_bd * rank[1];
        action[2] = target_angle_ac * rank[2];
        action[3] = target_angle_bd * rank[3];

        for (int i = 0; i < 4; i++) {
            lifthigh(i, action[i]);
        }
    }
}


// ================= 初始化 (保持原名) =================

void prepare(void)
{
    for (int i = 0; i < 4; i++) {

        if (!device_is_ready(dm_motor[i])) {
            LOG_ERR("motor%d NOT READY!", i);
            continue;
        }

        LOG_INF("motor%d ready", i);

        motor_control(dm_motor[i], ENABLE_MOTOR);
        k_msleep(10);   // ⚠️ 很重要：给驱动时间

        motor_set_mode(dm_motor[i], MIT);
        k_msleep(10);

        LOG_INF("motor%d enabled + MIT mode", i);
    }
}


// ================= 主函数 =================

int main(void)
{
    k_msleep(200);

    LOG_INF("=== Lift Demo Start ===");

    // 初始化电机设备指针数组
    dm_motor[0] = dm_motor000;
    dm_motor[1] = dm_motor001;
    dm_motor[2] = dm_motor002;
    dm_motor[3] = dm_motor003;

    // 检查 SBUS 设备就绪
    if (!device_is_ready(sbus)) {
        LOG_ERR("SBUS device NOT READY!");
    } else {
        LOG_INF("SBUS device ready");
    }

    prepare();

    hold_current_target();

    // 启动时不主动移动，但逻辑档位从0档开始
    LOG_INF("Start at gear 1/%d, waiting for trigger.", MAX_GEAR);

    while (1) {
        // 获取方向通道和触发通道的值
        float direction_sbus = sbus_get_percent(sbus, SBUS_DIRECTION_CH);
        float trigger_sbus = sbus_get_percent(sbus, SBUS_TRIGGER_CH);

        // 档位控制：通道4决定升降方向，通道7变化触发档位切换
        gear_control_update(direction_sbus, trigger_sbus);

        // 持续重发当前档位目标，提高受压时的位置保持能力
        hold_current_target();

        // 控制频率（5ms周期，适合DM电机）
        k_msleep(5);
    }

    return 0;
}
